/*global Autolinker:true*/  // Meteor creates a file-scope global for exporting. This comment prevents a potential JSHint warning.
Autolinker = window.Autolinker;
delete window.Autolinker;
